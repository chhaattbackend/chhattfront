<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('mobile/index.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('mobile/property/property.css')); ?>" />

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('mobile/property/btnsearch.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
    $a = URL::current();
    $a = explode('/', $a);
    $a = end($a);
    ?>
    <div class="buy_rent_main_div">
        <a href="<?php echo e(route('filter', 'buy')); ?>" id="btnbuy" class="for-sale <?php if($a=='buy' ): ?> activeBtn <?php endif; ?> ">
                <button onclick=" search('buy')">Buy</button>
        </a>
        <a href="<?php echo e(route('filter', 'rent')); ?>" id="btnrent" class="for-rent <?php if($a=='rent' ): ?> activeBtn <?php endif; ?>">
            <button onclick="search('rent')">Rent</button>
        </a>
        <a href="<?php echo e(route('filter', 'booking')); ?>" id="btnbooking" class="for-booking <?php if($a=='booking' ): ?> activeBtn <?php endif; ?> ">
            <button onclick="search('booking')">Booking</button>
        </a>
    </div>
    <?php echo $__env->make('frontend.property.mobile.btnsearch.ajax', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mobile.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/property/mobile/btnsearch/search.blade.php ENDPATH**/ ?>