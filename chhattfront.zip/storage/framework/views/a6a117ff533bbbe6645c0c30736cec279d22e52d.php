<div class="mapCardContainer">
    <div class="d-flex justify-content-between">
        <h2 class="fw-bold">Agencies</h2>
        <div class="d-flex">
            <div class="ms-4">
                <button onclick="window.location='<?php echo e(route('agency')); ?>'" class="themebtn2 px-3 py-1 ms-1">View
                    all</button>
            </div>
        </div>
    </div>
    <div class="position-relative mt-5">
        <div class="sliderBtnLeft text-right m-auto">
            <i class="scroll-left bi bi-arrow-left-circle-fill"></i>
        </div>
        <!--image allary list-->
        <ul id="box-wrapper" class="boxWrapper ps-0">
            <!--apply loop on this li-->
            <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $a = str_replace('(', '', str_replace(' ', '-', strtolower($item->name))) . '-' . strtolower($item->areaOne->city->name) . '-' . $item->id;
                ?>
                <li class="scroll-img-list ms-3 me-1 p-2">

                    <a class="text-decoration-none position-relative" href="<?php echo e(route('single.agency', [str_replace(')', '', $a)])); ?>">

                        <div class="imageSection">

                            <?php if($item->image != null): ?>
                                <img class="slideImg"
                                    src="https://chhatt.s3.ap-south-1.amazonaws.com/agencies/<?php echo e($item->image); ?>"
                                    alt="" />
                            <?php else: ?>
                                <img src="https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg"
                                    alt="" class="slideImg">

                            <?php endif; ?>
                        </div>

                        <div class="text-dark paraContainer">
                            <div class="mt-1">
                                <div class="d-flex justify-content-between">
                                    <h6 class="lightColor"><?php echo e(optional($item->areaOne->city)->name); ?></h6>
                                </div>
                                <div class="mt-2">
                                    <strong class="mt-5"><?php echo e(optional($item)->name); ?></strong>
                                </div>
                                <h6 class="mt-2">
                                    <strong>
                                        <?php echo e(optional($item->user)->name); ?>

                                    </strong>
                                </h6>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
        <div class="sliderBtnRight col-1 m-auto">
            <i class="scroll-right bi bi-arrow-right-circle-fill"></i>
        </div>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/layouts/agency.blade.php ENDPATH**/ ?>