<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/index.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/contruction/ccat1.css')); ?>" />

<?php $__env->stopSection(); ?>


<?php $__env->startSection('headercontent'); ?>
    <div class="mn_divz">
        <div class="backgz">
            <div class="backg_sdivz">
                <?php if($bcategories->isEmpty()): ?>
                    <h1>Error</h1>
                <?php else: ?>
                    <h1 class="fw-bold"><?php echo e($bcategories[0]->category->name); ?></h1>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <?php
    $count = 0;
    ?>

    <?php $__currentLoopData = $bcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $count = 0;
        ?>

        <div id="serch_option_show" class="main_div_list">
            <div class="mainList1">

                <div id="main_List<?php echo e($item->id); ?>" class="lst_div d-flex" style="height: 220px; overflow: hidden;">
                    <div class="litsdj col-md-2 pt-2 mt-4">
                        <div class="list1_div1">
                            <img src="https://chhatt.s3.ap-south-1.amazonaws.com/construction/bcategories/<?php echo e($item->image); ?>"
                                width="115px" height="115px" alt="" />
                        </div>
                        <div class="list1_div2">
                            <h6>
                                <br>
                                <?php echo e($item->name); ?>

                            </h6>
                            <p>(<?php echo e($item->subcategories->count()); ?>)</p>
                        </div>
                    </div>
                    <div class="list row m-auto flex-wrap">
                        <?php $__currentLoopData = $item->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $count++;
                            ?>

                            <div class="lit1 col-md-3 p-0  mt-4">
                                <div class="list1_div1">
                                    <a href="<?php echo e(route('construction.productlist', ['id' => $subItem->id])); ?>">

                                        <img src="https://chhatt.s3.ap-south-1.amazonaws.com/construction/ccategories/<?php echo e($subItem->image); ?>"
                                            width="115px" height="115px" alt="" />
                                    </a>
                                </div>
                                <div class="list1_div2">
                                    <h6 class="ellipse">
                                        <br>
                                        <?php echo e($subItem->name); ?>

                                    </h6>
                                    <p>(<?php echo e($subItem->subcategories->count() ?? 'no category'); ?>)</p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
            <?php if($count > 4): ?>
                <button onclick="changewidth(<?php echo e($item->id); ?>)" class="btns">
                    View More
                </button>
                <input hidden type="text" id="view_more<?php echo e($item->id); ?>" value="true">
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>



<?php $__env->startSection('personalscripts'); ?>
    <script>
        // var serch_option1 = document.getElementById("mainList1");
        // var view1 = document.getElementById("view_more1");
        // var view_more_bool1 = false
        // view1.addEventListener("click", () => {
        //     view_more_bool1 = !view_more_bool1
        //     if (view_more_bool1 === true) {
        //         serch_option1.style.transition = "300ms";
        //         serch_option1.style.height = "auto";
        //     } else if (view_more_bool1 === false) {
        //         serch_option1.style.transition = "300ms";
        //         serch_option1.style.height = "250px";
        //     }
        // });



        function changewidth(id) {

            var serch_option1 = document.getElementById("main_List"+id);
            // console.log(serch_option1)

            var view1 = document.getElementById("view_more"+id);
            // console.log(view1)

            if (view1.value == 'true') {
                serch_option1.style.transition = "300ms";
                serch_option1.style.height = "auto";
                view1.value = 'false';


            } else if (view1.value == 'false') {
                // console.log('false')
                view1.value = 'true';

                serch_option1.style.transition = "300ms";
                serch_option1.style.height = "220px";
            }
            // console.log(id)

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/construction/home/b_cat_list.blade.php ENDPATH**/ ?>