

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('mobile/property/properties.css')); ?>" />
    <style>
        li.page-item {
            display: none;
        }

        .page-item:first-child,
        .page-item:nth-child(2),
        .page-item:nth-last-child(2),
        .page-item:last-child,
        .page-item.active,
        .page-item.disabled {
            display: block;
        }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('functions.convert_rupee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BUTTONS START -->
    <div class="brb_buttons">
        <div class="container">
            <div class="row height d-flex justify-content-center align-items-center">
                <div class="col-md-12">
                     <input type="text" name="keyword" class="form-control p-2 "
                            placeholder="Search Agency">

                </div>
            </div>
        </div>
    </div>
    <!-- BUTTONS END -->

    <!-- PROPERTIES LIST START -->
    <div class="propertyListMobile">
        <div class="top">
            <p> Find The Best Real Estate Agencies </p>
        </div>
        <?php echo $__env->make('frontend.agency.mobile.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mobile.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/agency/mobile/index.blade.php ENDPATH**/ ?>