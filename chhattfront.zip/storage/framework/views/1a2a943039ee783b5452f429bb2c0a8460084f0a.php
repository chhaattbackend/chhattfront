<?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-sm-4 col-lg-3 mb-4">
        <!-- property card start -->
        <div class="propertyCard p-2">
            <?php
                $a = str_replace('(', '', str_replace(' ', '-', strtolower($item->name))) . '-' . strtolower($item->areaOne->city->name) . '-' . $item->id;
            ?>
            <a class="text-decoration-none position-relative"
                href="<?php echo e(route('single.agency', [str_replace(')', '', $a)])); ?>">
                <div class="imageSection">
                    <img class="slideImg" src='https://chhatt.s3.ap-south-1.amazonaws.com/agencies/<?php echo e($item->image); ?>'
                        alt="" />
                </div>
                <div class="text-dark paraContainer">
                    <div class="mt-1">
                        <div class="d-flex justify-content-between">
                            
                            <h6 class="lightColor">Karachi</h6>
                        </div>
                        <div class="text-start mt-2">
                            <strong class="mt-5"><?php echo e($item->name); ?></strong>
                        </div>
                        <h6 class="text-start mt-2">
                            <strong>
                                <?php echo e($item->user->name); ?>

                            </strong>
                        </h6>
                    </div>
                </div>
            </a>
        </div>
        <!-- property card end -->
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/agency/list.blade.php ENDPATH**/ ?>