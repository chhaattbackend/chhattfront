<?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <li>
        <div>
            <a href="<?php echo e(route('single.agency', $item->id )); ?>" class="property_card_main_div text-decoration-none">
                <img src="https://chhatt.s3.ap-south-1.amazonaws.com/agencies/<?php echo e(@$item->image); ?>"
                    class="propertyImg" alt="" />
                <p> <?php echo e(@$item->areaOne->city->name); ?> </p>
                <b>
                   <?php echo e(@$item->name); ?>

                </b>
                <p>
                    <b class="text-dark fw-light"><?php echo e(@$item->user->name); ?></b>
                </p>
            </a>
        </div>
    </li>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/property/mobile/agencylist.blade.php ENDPATH**/ ?>