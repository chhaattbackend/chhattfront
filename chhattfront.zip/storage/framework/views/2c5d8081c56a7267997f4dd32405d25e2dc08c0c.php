<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('mobile/property/properties.css')); ?>" />
    <style>
        li.page-item {
            display: none;
        }

        .page-item:first-child,
        .page-item:nth-child(2),
        .page-item:nth-last-child(2),
        .page-item:last-child,
        .page-item.active,
        .page-item.disabled {
            display: block;
        }
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('functions.convert_rupee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- BUTTONS START -->
    <div class="brb_buttons">
        <a href="">
            <button>
                Buy
            </button>
        </a>
        <a href="">
            <button>
                Rent
            </button>
        </a>
        <a href="">
            <button>
                Booking
            </button>
        </a>
    </div>
    <!-- BUTTONS END -->

    <!-- PROPERTIES LIST START -->
    <div class="propertyListMobile">
        <div class="top">
            <p> Best Properties For You </p>
        </div>
        <div class="cards_container">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id = @$item->areaOne->city->name . '-' . @$item->type . '-' . @$item->property_type . '-' . @$item->property_for . '-' . @$item->areaOne->name . '-' . @$item->areaTwo->name . '-' . $item->id;
                    $id = str_replace(str_split('\\/:*?"<>|()'), '-', strtolower($id));
                    $id = str_replace(str_split(' '), '_', strtolower($id));
                    $id = strtolower($id);
                ?>


                <a href="<?php echo e(route('single.property', $id)); ?>" class="card_div text-decoration-none">

                    <?php if(!$item->images->isEmpty()): ?>
                        <img class="propertyImg"
                            src="https://chhatt.s3.ap-south-1.amazonaws.com/properties/<?php echo e($item->images[0]->name); ?>"
                            alt="" />
                    <?php else: ?>
                        <img src="https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg"
                            alt="" class="propertyImg">

                    <?php endif; ?>

                    <p> <?php echo e($item->type); ?></p>
                    <b>
                        <?php echo e($item->property_for); ?>in <?php echo e(optional($item->areaThree)->name); ?>,
                        <?php echo e(optional($item->areaTwo)->name); ?>,
                        <?php echo e(optional($item->areaOne)->name); ?>

                    </b>
                    <p>
                        <b>
                            <?php if($item->price == null): ?>
                                <span style="background: red;" class="badge badge-pill badge-danger">On Request</span>
                            <?php else: ?>
                                Rs: <?php echo e(convert_rupee($item->price)); ?>

                            <?php endif; ?>
                        </b>
                    </p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

        <div class="d-flex justify-content-center ">
            <nav aria-label="Page navigation example">
                <?php echo e($properties->links()); ?>

            </nav>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mobile.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/property/mobile/search.blade.php ENDPATH**/ ?>