
<div class="cards_container">
    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $id = str_replace('(', '', str_replace(' ', '-', strtolower($item->name))) . '-' . strtolower($item->areaOne->city->name) . '-' . $item->id;
        ?>


        <div class="card_div text-decoration-none">
            <a href="<?php echo e(route('single.agency', [str_replace(')', '', $id)])); ?>">
                <img class="propertyImg"
                    src='https://chhatt.s3.ap-south-1.amazonaws.com/agencies/<?php echo e($item->image); ?>' alt="" />
            </a>
            <p> <?php echo e($item->areaOne->city->name ?? 'Karachi'); ?></p>
            <b>
                <?php echo e($item->name); ?>

            </b>
            <p>
                <b style="color: rgb(0, 51, 255)">
                    <?php echo e($item->user->name); ?>

                </b>
            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="d-flex justify-content-center ">
    <nav aria-label="Page navigation example">
        <?php echo e($agencies->links()); ?>

    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/agency/mobile/list.blade.php ENDPATH**/ ?>