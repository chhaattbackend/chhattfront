<?php
function convert_rupee($amount)
{
    $length = strlen($amount);
    if ($length >= 6 && $length <= 7) {
        return round($amount / 100000, 2) . ' Lacs';
    } elseif ($length >= 8 && $length <= 9) {
        return round($amount / 10000000, 2) . ' Cr.';
    } elseif ($length >= 4 && $length <= 5) {
        return round($amount / 1000, 2) . ' K';
    } else {
        return 0;
    }
}
?>

<?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $id = @$item->areaOne->city->name . '-' . @$item->type . '-' . @$item->property_type . '-' . @$item->property_for . '-' . @$item->areaOne->name . '-' . @$item->areaTwo->name . '-' . $item->id;
        $id = str_replace(str_split('\\/:*?"<>|()'), '-', strtolower($id));
        $id = str_replace(str_split(' '), '_', strtolower($id));
        $id = strtolower($id);
    ?>


    <li class="scroll-img-list ms-3 me-1 p-2">
        <a class="text-decoration-none position-relative" href="<?php echo e(route('single.property', $id)); ?>">
            <div class="imageSection">


                <?php if(!$item->images->isEmpty()): ?>
                    <img class="slideImg"
                        src="https://chhatt.s3.ap-south-1.amazonaws.com/properties/<?php echo e($item->images[0]->name); ?>"
                        alt="" />
                <?php else: ?>
                    <img src="https://st4.depositphotos.com/14953852/24787/v/600/depositphotos_247872612-stock-illustration-no-image-available-icon-vector.jpg"
                        alt="" class="slideImg">

                <?php endif; ?>
            </div>
            <div class="text-dark paraContainer">
                <div class="mt-1">
                    <div class="d-flex justify-content-between">
                        <h6 class="lightColor"><?php echo e($item->type); ?></h6>
                        <h6 class="lightColor"><?php echo e($item->updated_at->diffForHumans()); ?></h6>
                    </div>
                    <div class="mt-2 title ellipse">
                        <strong class="mt-5"><?php echo e($item->property_for); ?>in <?php echo e(optional($item->areaThree)->name); ?>,
                            <?php echo e(optional($item->areaTwo)->name); ?>,
                            <?php echo e(optional($item->areaOne)->name); ?></strong>
                    </div>
                    <h6 class="mt-2">
                        <strong>
                            <?php if($item->price == null): ?>
                                <span style="background: red;" class="badge badge-pill badge-danger">On Request</span>
                            <?php else: ?>
                                Rs: <?php echo e(convert_rupee($item->price)); ?>

                            <?php endif; ?>
                        </strong>
                    </h6>
                </div>
                <div class="d-flex justify-content-between mt-3">
                    <button class="w-100 themebtn py-1 text-white">View more</button>
                    <button class="w-100 ms-3">Contact Us</button>
                </div>
            </div>
        </a>
    </li>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/frontend/home/list.blade.php ENDPATH**/ ?>