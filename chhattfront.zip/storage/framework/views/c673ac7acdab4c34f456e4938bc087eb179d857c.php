<?php $__env->startSection('style'); ?>
    

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/home/home.css')); ?>" /> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/contact.css')); ?>" />
    <style>
        .mn_div {
            background-image: url("../../assets/propertyCard.webp") !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headercontent'); ?>
<div class="mn_divz">
      <div class="backgz">
        <div class="backg_sdivz">
          <h1>Contact Us</h1>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />


    <img src="<?php echo e(asset('assets/map.webp')); ?>" alt="Contactus" style="width: 100%; height: 500px;">
    <!-- BANNER END -->

    <!-- FORM START -->
    <div class="contactSection">
        <div class="messageForm">
            <h3>Send us a message</h3>
            <p>
                Chhatt aims and relies on simple and easier communication with clients
                and providing real estate solutions at the touch of a finger. In short,
                Chhatt is a point of elevation which gives you a strategic view of the
                real estate market.
            </p>
            <div class="inputsContainer">
                <input type="text" placeholder="Username" />
                <input type="text" placeholder="Email" />
                <input type="number" placeholder="Phone Number" />
            </div>
            <textarea rows="5" placeholder="Message"></textarea>
            <br />
            <button>
                Send Email
            </button>
        </div>
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chhattfront\resources\views/layouts/contact.blade.php ENDPATH**/ ?>