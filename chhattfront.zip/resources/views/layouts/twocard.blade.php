  <!-- two-cards start -->
  <div class="two-card">
      <div class="fdiv" title="Properties Site">
        <div class="fdiv_fch">
          <p>Hundred of properties</p>
          <p>from top locations</p>
        </div>
        <div class="fdiv_sch">
          <!-- <Link to='/property'> -->
          <button type="button" class="btn btn-primary">Properties Site</button>
          <!-- </Link> -->
        </div>
      </div>
      <div class="sdiv" title="Construction Site">
        <div class="sdiv_fch">
          <p>Find the best</p>
          <p>construction materials</p>
        </div>
        <div class="sdiv_sch">
          <!-- <Link to='construction'> -->
          <button>Construction Site</button>
          <!-- </Link> -->
        </div>
      </div>
    </div>
    <!-- tow cards end -->