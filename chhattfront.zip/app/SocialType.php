<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SocialType extends Model
{
    protected $fillable = ['name'];
}
